```python
# ART Adherence Prediction for Kenyan Adolescents
# ======================================================
# This notebook implements the data-driven model described in the research proposal
# to predict antiretroviral therapy (ART) adherence among Kenyan adolescents with HIV
# 1. Import essential libraries
# Data manipulation libraries
import pandas as pd
import numpy as np
# Visualization libraries
import matplotlib.pyplot as plt
import seaborn as sns
# Statistical analysis
from scipy import stats
!pip install mysql-connector-python
# Machine learning libraries - as specified in proposal
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
# Models mentioned in proposal
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
# Note: We'll use gradient boosting from sklearn instead of XGBoost
from sklearn.ensemble import GradientBoostingClassifier
# Evaluation metrics
from sklearn.metrics import (classification_report, confusion_matrix,
                            roc_auc_score, precision_recall_curve,
                            roc_curve, auc)
# For handling imbalanced data (SMOTE) as mentioned in proposal
from imblearn.over_sampling import SMOTE
# Database connection for XAMPP/MySQL as specified in proposal
import mysql.connector
# Check if all packages are available
try:
    # Test one import from each major library
    pd.DataFrame()
    np.array([])
    plt.figure()
    sns.set()
    stats.norm()
    mysql.connector
    print("All required libraries successfully imported!")
except Exception as e:
    print(f"Error importing libraries: {e}")
    print("Please install missing packages before proceeding.")
# Set visualization defaults
plt.style.use('default')
sns.set()
print("Setup complete! proceeding  with data generation and analysis.")
```

    Requirement already satisfied: mysql-connector-python in c:\users\user\anaconda3\lib\site-packages (9.2.0)
    All required libraries successfully imported!
    Setup complete! proceeding  with data generation and analysis.
    


    <Figure size 640x480 with 0 Axes>



```python
import numpy as np
import pandas as pd

# Set random seed for reproducibility
np.random.seed(42)

# Define the number of records (10,000 as stated in my proposal)
n_samples = 10000

print("Generating synthetic ART adherence data for Kenyan adolescents...")

# ======= DEMOGRAPHIC FEATURES =======
print("Generating demographic features...")
age = np.random.randint(10, 20, n_samples)  # Age between 10-19 years
gender = np.random.choice(['Male', 'Female'], n_samples)
location = np.random.choice(['Urban', 'Rural'], n_samples, p=[0.6, 0.4])  # 60% urban, 40% rural
education_level = np.random.choice(['Primary', 'Secondary', 'Tertiary'], n_samples, p=[0.5, 0.4, 0.1])
socioeconomic_status = np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.5, 0.3, 0.2])

# ======= CLINICAL FEATURES =======
print("Generating clinical features...")
cd4_count = np.clip(np.random.normal(500, 200, n_samples), 50, 1200)
viral_load = np.clip(np.exp(np.random.normal(6, 1.5, n_samples)), 20, 100000)
treatment_duration = np.clip(np.random.gamma(shape=2, scale=10, size=n_samples), 1, 60)
side_effects = np.random.choice(['None', 'Mild', 'Severe'], n_samples, p=[0.6, 0.3, 0.1])
comorbidities = np.random.choice(['None', 'One', 'Multiple'], n_samples, p=[0.7, 0.2, 0.1])
drug_regimen = np.random.choice(['First-line', 'Second-line', 'Third-line'], n_samples, p=[0.7, 0.2, 0.1])

# ======= SOCIAL AND ENVIRONMENTAL FEATURES =======
print("Generating social and environmental features...")
family_support = np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.3, 0.4, 0.3])
distance_to_clinic = np.random.beta(2, 5, n_samples) * 50
awareness_status = np.random.choice([0, 1], n_samples, p=[0.3, 0.7])  # 70% are aware of their status
stigma_experience = np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.4, 0.4, 0.2])
peer_support = np.random.choice([0, 1], n_samples, p=[0.6, 0.4])

# Create the base dataframe
data = pd.DataFrame({
    'Age': age,
    'Gender': gender,
    'Location': location,
    'Education_Level': education_level,
    'Socioeconomic_Status': socioeconomic_status,
    'CD4_Count': cd4_count.astype(int),
    'Viral_Load': viral_load.astype(int),
    'Treatment_Duration': treatment_duration.astype(int),
    'Side_Effects': side_effects,
    'Comorbidities': comorbidities,
    'Drug_Regimen': drug_regimen,
    'Family_Support': family_support,
    'Distance_to_Clinic': distance_to_clinic,
    'Awareness_Status': awareness_status,
    'Stigma_Experience': stigma_experience,
    'Peer_Support': peer_support
})
# ======= ADHERENCE RISK CALCULATION =======
print("Calculating adherence risk...")

def calculate_adherence_risk(row):
    risk = 0.2  # Base risk (starting point for all patients)
    
    # Increase risk if the patient is unaware of their HIV status
    if row['Awareness_Status'] == 0:
        risk += 0.50
    
    # Additional risk factors
    if row['Age'] >= 17:
        risk += 0.08
    if row['Gender'] == 'Male':
        risk += 0.04
    if row['Location'] == 'Rural':
        risk += 0.05
    if row['CD4_Count'] < 200:
        risk += 0.10
    if row['Viral_Load'] > 10000:
        risk += 0.08
    if row['Side_Effects'] == 'Severe':
        risk += 0.15
    
    return max(0, min(risk, 0.95))  # Ensure risk stays between 0 and 95%

# Calculate adherence risk for each patient
data['Adherence_Risk'] = data.apply(calculate_adherence_risk, axis=1)

# ======= INTRODUCING MISSING VALUES =======
print("Introducing missing values...")
for col in ['CD4_Count', 'Viral_Load', 'Distance_to_Clinic']:
    data.loc[data.sample(frac=0.1).index, col] = np.nan  # 10% missing in numeric features
for col in ['Education_Level', 'Side_Effects']:
    data.loc[data.sample(frac=0.05).index, col] = np.nan  # 5% missing in categorical features

# ======= INTRODUCING OUTLIERS =======
print("Introducing outliers...")
outlier_indices = np.random.choice(data.index, size=10, replace=False)  # Select 10 random rows for outliers
data.loc[outlier_indices[:5], 'Viral_Load'] = [150000, 200000, 180000, 220000, 250000]  # Extreme values
data.loc[outlier_indices[5:], 'Distance_to_Clinic'] = [100, 120, 110, 130, 150]  # Unrealistic travel distances


# ======= ADHERENCE STATUS GENERATION =======
print("Generating adherence status...")

# Based on adherence risk, create adherence status: 0 = Non-adherent, 1 = Adherent
data['Adherence_Status'] = data.apply(
    lambda row: np.random.choice([0, 1], p=[1 - row['Adherence_Risk'], row['Adherence_Risk']]),
    axis=1
)  

# ======= FEATURE ENGINEERING =======
print("Creating new engineered features for better EDA...")

# Categorizes age into three groups (10-13, 14-16, 17-19) to analyze adherence differences.
data['Age_Group'] = pd.cut(data['Age'], bins=[9, 13, 16, 19], labels=['10-13', '14-16', '17-19'])

# Creates a binary feature (1 or 0) indicating if a patient has high family support and knows their HIV status.
data['Support_Awareness_Interaction'] = ((data['Family_Support'] == 'High') & (data['Awareness_Status'] == 1)).astype(int)

# Adjusts travel burden by increasing the distance by 1.5x for rural patients to reflect real-world challenges.
data['Location_Distance_Interaction'] = data.apply(
    lambda row: row['Distance_to_Clinic'] * 1.5 if row['Location'] == 'Rural' else row['Distance_to_Clinic'],
    axis=1
)

# Convert viral load to categorical status ('Suppressed' if <1000, otherwise 'Unsuppressed').
# Adjust viral suppression status based on adherence status.
data['Viral_Suppression_Status'] = data.apply(
    lambda row: 'Suppressed' if row['Adherence_Status'] == 1 and row['Viral_Load'] < 1000 else 'Unsuppressed',
    axis=1
)
# Calculates treatment complexity based on drug regimen (higher lines are more complex) and side effects severity.
data['Treatment_Complexity_Score'] = data.apply(
    lambda row: (2 if row['Drug_Regimen'] == 'Third-line' else 1 if row['Drug_Regimen'] == 'Second-line' else 0) +
                (2 if row['Side_Effects'] == 'Severe' else 1 if row['Side_Effects'] == 'Mild' else 0),
    axis=1
)

# Drops the temporary adherence risk column since it was only used for generating adherence status.
data.drop('Adherence_Risk', axis=1, inplace=True)
# Save the dataset to a CSV file
data.to_csv('art_adherence_data.csv', index=False)
print("\nDataset saved to 'art_adherence_data.csv'")

print(f"Synthetic dataset created with {n_samples} records")
```

    Generating synthetic ART adherence data for Kenyan adolescents...
    Generating demographic features...
    Generating clinical features...
    Generating social and environmental features...
    Calculating adherence risk...
    Introducing missing values...
    Introducing outliers...
    Generating adherence status...
    Creating new engineered features for better EDA...
    
    Dataset saved to 'art_adherence_data.csv'
    Synthetic dataset created with 10000 records
    

# **EDA**

This phase focused on understanding the structure, quality, and relationships within the synthetic dataset to prepare for modeling.

### 3.2Missing Values
A heatmap revealed the distribution of missing data:
- Numeric variables like `CD4_Count`, `Viral_Load`, and `Distance_to_Clinic` had ~10% missing values.
- Categorical variables like `Education_Level` and `Side_Effects` had ~5% missing.
These will be handled in preprocessing.

### 3.3 Target Variable Distribution
The dataset contains:
- **4358 Adherent cases** (label = 1)
- **5642 Non-Adherent cases** (label = 0)

This reflects a slight imbalance (44% vs 56%), which is acceptable and realistic based on known adherence issues among adolescents. No severe class imbalance handling is required at this stage.

### 3.4 Numerical Feature Analysis
A boxplot analysis revealed:
- **Viral Load** has significant outliers.
- Other features like `CD4_Count` and `Treatment_Duration` are more compact.
This suggests that viral load may need transformation or outlier handling.

### 3.5 Correlation Heatmap
Key findings from the correlation matrix:
- **Awareness_Status** has a moderate negative correlation (-0.45) with **Adherence_Status** — supporting your hypothesis that awareness improves adherence.
- **Support_Awareness_Interaction** correlates positively (0.33) with **Awareness_Status**.
- **Distance_to_Clinic** is highly correlated (0.93) with `Location_Distance_Interaction`, indicating redundancy.

As a result, `Distance_to_Clinic` was dropped.

### 3.6Viral Load by Adherence
Distribution plots show:
- High viral loads appear in both adherence groups.
- Some adherent cases still have high viral loads, indicating that suppression may depend on more than just adherence.
-A distribution plot showed that viral load varies widely across both adherence categories, with high outliers present in both. This supports the inclusion of viral load as a predictor after appropriate outlier treatment.


### 3.7 Chi-Square Tests on Categorical Features
Statistically significant associations with adherence status:
- **Gender** (p < 0.0001)
- **Location** (p = 0.0015)
- **Side Effects** (p < 0.0001)

These variables will be encoded and retained for modeling.

---

### 3.8 Feature Selection Summary

| Action             | Feature                             | Reason                                                      |
|--------------------|--------------------------------------|--------------------------------------------------------------|
| **Dropped**        | `Distance_to_Clinic`                 | High correlation (0.93) with `Location_Distance_Interaction` |
| **Retain & Encode**| `Gender`, `Location`, `Side_Effects` | Significant chi-square association with target              |
| **Important**      | `Awareness_Status`, `Support_Awareness_Interaction`, `Viral_Load` | Strong correlation or real-world importance       |
| **To Test**        | `CD4_Count`, `Treatment_Duration`    | Moderate effect, potentially important predictors           |

These insights guide the next step: data cleaning, encoding, and modeling.



# **1.data inspection**


```python
# Load dataset
df = pd.read_csv("art_adherence_data.csv")

# Display first few rows
print("First 5 records:")
print(df.sample(5))

# Check data structure
print("\nDataset Info:")
print(df.info())

# Summary statistics
print("\nSummary Statistics:")
print(df.describe())

# Check for missing values
print("\nMissing Values Per Column:")
print(df.isnull().sum())
```

    First 5 records:
          Age  Gender Location Education_Level Socioeconomic_Status  CD4_Count  \
    6423   18  Female    Rural       Secondary                 High      709.0   
    9106   19    Male    Urban         Primary               Medium        NaN   
    9368   16    Male    Rural         Primary               Medium      543.0   
    6177   17  Female    Rural        Tertiary               Medium        NaN   
    9968   18    Male    Urban        Tertiary               Medium      649.0   
    
          Viral_Load  Treatment_Duration Side_Effects Comorbidities  ...  \
    6423         NaN                   2       Severe           NaN  ...   
    9106       184.0                  25          NaN           NaN  ...   
    9368       198.0                   9         Mild           NaN  ...   
    6177       772.0                  12          NaN           NaN  ...   
    9968       324.0                   7          NaN           One  ...   
    
         Distance_to_Clinic Awareness_Status  Stigma_Experience  Peer_Support  \
    6423           9.790254                1             Medium             1   
    9106          18.540714                0                Low             0   
    9368          14.302175                1             Medium             0   
    6177           7.324641                1                Low             0   
    9968           7.048700                0             Medium             0   
    
         Adherence_Status  Age_Group  Support_Awareness_Interaction  \
    6423                0      17-19                              1   
    9106                0      17-19                              0   
    9368                0      14-16                              0   
    6177                1      17-19                              0   
    9968                1      17-19                              0   
    
         Location_Distance_Interaction  Viral_Suppression_Status  \
    6423                     14.685382              Unsuppressed   
    9106                     18.540714              Unsuppressed   
    9368                     21.453263              Unsuppressed   
    6177                     10.986962                Suppressed   
    9968                      7.048700                Suppressed   
    
          Treatment_Complexity_Score  
    6423                           3  
    9106                           1  
    9368                           1  
    6177                           2  
    9968                           0  
    
    [5 rows x 22 columns]
    
    Dataset Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10000 entries, 0 to 9999
    Data columns (total 22 columns):
     #   Column                         Non-Null Count  Dtype  
    ---  ------                         --------------  -----  
     0   Age                            10000 non-null  int64  
     1   Gender                         10000 non-null  object 
     2   Location                       10000 non-null  object 
     3   Education_Level                9500 non-null   object 
     4   Socioeconomic_Status           10000 non-null  object 
     5   CD4_Count                      9000 non-null   float64
     6   Viral_Load                     9000 non-null   float64
     7   Treatment_Duration             10000 non-null  int64  
     8   Side_Effects                   3775 non-null   object 
     9   Comorbidities                  3024 non-null   object 
     10  Drug_Regimen                   10000 non-null  object 
     11  Family_Support                 10000 non-null  object 
     12  Distance_to_Clinic             9000 non-null   float64
     13  Awareness_Status               10000 non-null  int64  
     14  Stigma_Experience              10000 non-null  object 
     15  Peer_Support                   10000 non-null  int64  
     16  Adherence_Status               10000 non-null  int64  
     17  Age_Group                      10000 non-null  object 
     18  Support_Awareness_Interaction  10000 non-null  int64  
     19  Location_Distance_Interaction  9000 non-null   float64
     20  Viral_Suppression_Status       10000 non-null  object 
     21  Treatment_Complexity_Score     10000 non-null  int64  
    dtypes: float64(4), int64(7), object(11)
    memory usage: 1.7+ MB
    None
    
    Summary Statistics:
                    Age    CD4_Count     Viral_Load  Treatment_Duration  \
    count  10000.000000  9000.000000    9000.000000        10000.000000   
    mean      14.497200   500.200333    1297.693778           19.450300   
    std        2.893964   197.469594    5477.759217           13.525451   
    min       10.000000    50.000000      20.000000            1.000000   
    25%       12.000000   362.000000     147.000000            9.000000   
    50%       15.000000   500.500000     410.500000           16.000000   
    75%       17.000000   635.000000    1107.250000           27.000000   
    max       19.000000  1167.000000  250000.000000           60.000000   
    
           Distance_to_Clinic  Awareness_Status  Peer_Support  Adherence_Status  \
    count         9000.000000      10000.000000  10000.000000      10000.000000   
    mean            14.431338          0.706900      0.394600          0.435800   
    std              8.353079          0.455207      0.488789          0.495886   
    min              0.051825          0.000000      0.000000          0.000000   
    25%              8.127243          0.000000      0.000000          0.000000   
    50%             13.389183          1.000000      0.000000          0.000000   
    75%             19.628429          1.000000      1.000000          1.000000   
    max            150.000000          1.000000      1.000000          1.000000   
    
           Support_Awareness_Interaction  Location_Distance_Interaction  \
    count                   10000.000000                    9000.000000   
    mean                        0.205300                      17.383561   
    std                         0.403941                      10.944628   
    min                         0.000000                       0.051825   
    25%                         0.000000                       9.342031   
    50%                         0.000000                      15.678407   
    75%                         0.000000                      23.457044   
    max                         1.000000                     225.000000   
    
           Treatment_Complexity_Score  
    count                10000.000000  
    mean                     0.869700  
    std                      0.937555  
    min                      0.000000  
    25%                      0.000000  
    50%                      1.000000  
    75%                      1.000000  
    max                      4.000000  
    
    Missing Values Per Column:
    Age                                 0
    Gender                              0
    Location                            0
    Education_Level                   500
    Socioeconomic_Status                0
    CD4_Count                        1000
    Viral_Load                       1000
    Treatment_Duration                  0
    Side_Effects                     6225
    Comorbidities                    6976
    Drug_Regimen                        0
    Family_Support                      0
    Distance_to_Clinic               1000
    Awareness_Status                    0
    Stigma_Experience                   0
    Peer_Support                        0
    Adherence_Status                    0
    Age_Group                           0
    Support_Awareness_Interaction       0
    Location_Distance_Interaction    1000
    Viral_Suppression_Status            0
    Treatment_Complexity_Score          0
    dtype: int64
    

# **2.Visualize missing values**



```python
plt.figure(figsize=(12, 6))
sns.heatmap(df.isnull(), cmap="magma", cbar=False, yticklabels=False)
plt.title("Missing Values Heatmap")
plt.show()
```


    
![png](output_6_0.png)
    


# **3.Checking Class Distribution (Adherence Status)**


```python
plt.figure(figsize=(10, 6))
sns.countplot(data=df, x="Adherence_Status", hue="Adherence_Status", palette=["#fc8d62", "#66c2a5"], legend=False)
plt.title("Adherence Status Distribution", fontsize=14)
plt.xlabel("Adherence Status (0 = Non-Adherent, 1 = Adherent)", fontsize=12)
plt.ylabel("Count", fontsize=12)
# Add count labels on top of each bar
ax = plt.gca()
for p in ax.patches:
    ax.annotate(f'{int(p.get_height())}', 
                (p.get_x() + p.get_width() / 2., p.get_height()), 
                ha = 'center', va = 'bottom', fontsize=12)
plt.xticks([0, 1], ['Non-Adherent (0)', 'Adherent (1)'])
plt.tight_layout()
plt.show()
# Print the exact counts
adherent_count = df[df['Adherence_Status'] == 1].shape[0]
non_adherent_count = df[df['Adherence_Status'] == 0].shape[0]
print(f"Adherent (1): {adherent_count} individuals")
print(f"Non-Adherent (0): {non_adherent_count} individuals")
```


    
![png](output_8_0.png)
    


    Adherent (1): 4358 individuals
    Non-Adherent (0): 5642 individuals
    

**4.Checking Outliers using Boxplots**


```python
numeric_cols = ["CD4_Count", "Viral_Load", "Treatment_Duration", "Distance_to_Clinic"]

plt.figure(figsize=(12,6))
df[numeric_cols].boxplot()
plt.xticks(rotation=45)
plt.title("Boxplot of Numerical Features")
plt.show()
```


    
![png](output_10_0.png)
    


# **5.Feature Correlation Analysis**


```python
plt.figure(figsize=(12,8))
# Select only numerical columns before computing correlations
numeric_df = df.select_dtypes(include=['number'])
sns.heatmap(numeric_df.corr(), annot=True, cmap="Spectral", linewidths=0.5)
plt.title("Feature Correlation Heatmap")
plt.savefig('heatmap.png')  # Saving image
plt.show()  
plt.close()  # Close to free up memory

```


    
![png](output_12_0.png)
    


 # **6.Comparing Adherence Groups**


```python
plt.figure(figsize=(10,6))
sns.boxplot(data=df, x="Adherence_Status", y="Viral_Load", hue="Adherence_Status", palette="coolwarm_r", legend=False)
plt.title("Viral Load Distribution by Adherence Status")
plt.show()
```


    
![png](output_14_0.png)
    


# **7.CHI-square test for categorical values**
**evaluates how diffrent categorical variables relate with adherence**


```python
from scipy.stats import chi2_contingency

# Select categorical columns to test
categorical_features = ["Gender", "Location", "Education_Level", "Side_Effects", "Comorbidities", 
                        "Drug_Regimen", "Family_Support", "Stigma_Experience", "Peer_Support"]

# Loop through each categorical feature and compute Chi-Square test
for col in categorical_features:
    contingency_table = pd.crosstab(df[col], df["Adherence_Status"])
    chi2, p, dof, expected = chi2_contingency(contingency_table)
    
    print(f"\n🔹 Chi-Square Test for {col} vs Adherence_Status:")
    print(f"   Chi-Square Score = {chi2:.4f}, p-value = {p:.4f}")

    # Interpretation
    if p < 0.05:
        print(f"   ✅ {col} has a **significant relationship** with adherence.")
    else:
        print(f"   ❌ {col} does **not** have a significant relationship with adherence.")
```

    
    🔹 Chi-Square Test for Gender vs Adherence_Status:
       Chi-Square Score = 18.9344, p-value = 0.0000
       ✅ Gender has a **significant relationship** with adherence.
    
    🔹 Chi-Square Test for Location vs Adherence_Status:
       Chi-Square Score = 10.0685, p-value = 0.0015
       ✅ Location has a **significant relationship** with adherence.
    
    🔹 Chi-Square Test for Education_Level vs Adherence_Status:
       Chi-Square Score = 2.2824, p-value = 0.3194
       ❌ Education_Level does **not** have a significant relationship with adherence.
    
    🔹 Chi-Square Test for Side_Effects vs Adherence_Status:
       Chi-Square Score = 60.6613, p-value = 0.0000
       ✅ Side_Effects has a **significant relationship** with adherence.
    
    🔹 Chi-Square Test for Comorbidities vs Adherence_Status:
       Chi-Square Score = 0.0000, p-value = 1.0000
       ❌ Comorbidities does **not** have a significant relationship with adherence.
    
    🔹 Chi-Square Test for Drug_Regimen vs Adherence_Status:
       Chi-Square Score = 0.0799, p-value = 0.9608
       ❌ Drug_Regimen does **not** have a significant relationship with adherence.
    
    🔹 Chi-Square Test for Family_Support vs Adherence_Status:
       Chi-Square Score = 5.2194, p-value = 0.0736
       ❌ Family_Support does **not** have a significant relationship with adherence.
    
    🔹 Chi-Square Test for Stigma_Experience vs Adherence_Status:
       Chi-Square Score = 2.9569, p-value = 0.2280
       ❌ Stigma_Experience does **not** have a significant relationship with adherence.
    
    🔹 Chi-Square Test for Peer_Support vs Adherence_Status:
       Chi-Square Score = 0.1328, p-value = 0.7155
       ❌ Peer_Support does **not** have a significant relationship with adherence.
    

## 4. Data Preprocessing

Before training any machine learning model, the data must be cleaned and prepared to ensure better performance and accuracy. Here are the main preprocessing steps applied:

### 4.1 Handling Missing Values
Some features had missing data (empty spaces). I handled this by:
- Filling numerical columns with their average values.
- Filling categorical columns with their most common values.

### 4.2 Outlier Treatment
Outliers are values that are far from the rest. These can confuse the model.
- I used a method called IQR (Interquartile Range) to find and cap extreme values in viral load.

### 4.3 Encoding Categorical Variables
Machine learning models only work with numbers. So I converted text features (like gender or side effects) into numbers.

### 4.4 Feature Scaling
Some values (like viral load) are much larger than others. I scaled the data so all features are on a similar scale.

These steps improve data quality and ensure the model doesn’t make wrong assumptions due to messy or unbalanced data.


### *4.1 Handling Missing Values*

Some parts of the dataset had missing information (blank spaces). I handled this by:
- Filling number columns (like CD4 Count and Viral Load) using the average value.
- Filling category columns (like Education Level and Side Effects) using the most common value.

This step ensures that the data is complete and ready for analysis and modeling.



```python
# Fill missing values in numeric columns using the average (mean)
data['CD4_Count'] = data['CD4_Count'].fillna(data['CD4_Count'].mean())
data['Viral_Load'] = data['Viral_Load'].fillna(data['Viral_Load'].mean())

# Fill missing values in categorical columns using the most frequent value (mode)
data['Education_Level'] = data['Education_Level'].fillna(data['Education_Level'].mode()[0])
data['Side_Effects'] = data['Side_Effects'].fillna(data['Side_Effects'].mode()[0])

```

### *4.2 Handling Outliers*

Outliers are unusual values in the data that are too high or unrealistic. They can affect the model's learning process.

I identified and adjusted:
- Extremely high viral load values
- Unrealistic travel distances to the clinic

This step helps make the data more balanced and reflective of real-life scenarios.



```python
# For Viral Load: Cap very high values to a maximum realistic limit
viral_load_threshold = 120000  # Any value above this is considered an outlier
data['Viral_Load'] = data['Viral_Load'].apply(lambda x: min(x, viral_load_threshold))

# For Distance to Clinic: Cap values above 80 km as unrealistic for adolescent access
distance_threshold = 80
data['Distance_to_Clinic'] = data['Distance_to_Clinic'].apply(lambda x: min(x, distance_threshold))

```

### *4.3 Converting Text to Numbers (Encoding)*

Our dataset contains information like gender, location, education level, and other features written as words (categories).

Since machine learning models only understand numbers, I need to convert these text-based values into numerical form.

I used two types of conversion:
-I used one-hot encoding on features like Education_Level that have more than two possible values, and label encoding for binary features like Gender.

This allows the model to use all features correctly without misinterpreting them.



```python
from sklearn.preprocessing import LabelEncoder

# Make a copy of the original dataset to avoid altering it directly
data_encoded = data.copy()

# Label encode ordinal features or binary categories
label_enc_cols = ['Gender', 'Location', 'Side_Effects', 'Comorbidities',
                  'Drug_Regimen', 'Family_Support', 'Stigma_Experience']

label_encoder = LabelEncoder()
for col in label_enc_cols:
    data_encoded[col] = label_encoder.fit_transform(data_encoded[col])

# One-hot encode non-ordinal features (where values have no order)
data_encoded = pd.get_dummies(data_encoded, columns=['Education_Level', 'Age_Group'], drop_first=True)

```

### *4.4 Removing Outliers (Unrealistic Extreme Values)*
Some values in the dataset were too high to be realistic, especially for features like Viral Load and Distance to Clinic. These are called outliers.

I had added these outliers on purpose when creating the synthetic data to make the analysis more meaningful. But now it's time to clean them up.

I removed the top 1% of the highest values in these columns. This helped improve the quality of the data and ensured that the model would not get confused by unrealistic cases.

By doing this, I made the dataset more accurate and reliable for machine learning.


```python
# Remove outliers in Viral_Load and Distance_to_Clinic
# I considered any values beyond the 99th percentile as extreme
upper_limit_viral_load = data['Viral_Load'].quantile(0.99)
upper_limit_distance = data['Distance_to_Clinic'].quantile(0.99)

# Filter the data to keep only values within reasonable limits
data = data[data['Viral_Load'] <= upper_limit_viral_load]
data = data[data['Distance_to_Clinic'] <= upper_limit_distance]

```


```python

```
